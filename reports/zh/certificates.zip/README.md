# Kissing-number constructions

Finite data and verification programs accompanying the Qiushi Engine reports.
Dimensions: 32, 33, 34, 35, 36, 37, 38, 39, 43, 45.

The defining inputs and counts are listed in `constructions/catalog/results.json`.
Each construction directory describes its coordinates and mathematical sources.
The proof is in the report containing this attachment.

## Verification

Use Python 3.10 or later, NumPy, SymPy, a C++ compiler and SageMath 10.
From this directory, check file integrity, then run all mathematical checks:

```sh
python3 tools/check_package.py
sage -python tools/reproduce.py --suite all --output ../kissing-verification
```

The output directory must be new and outside this extracted package.
Use `--list` to see the checks, or `--suite NAME` to run one.
No network access is required for the verification.

The two language editions embed the same archive. All coordinates and programs
are copied without alteration from the accompanying repository.
`LICENSE`, `RIGHTS.md` and `constructions/third-party.md` state the applicable terms.
